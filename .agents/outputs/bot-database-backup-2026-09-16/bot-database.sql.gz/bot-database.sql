--
-- PostgreSQL database dump
--

\restrict YUxpLEnX1zdOLj2bPFn3ooDAnJlFio1pAtowvtDgFpyHR5hOmN7IduDAAMqyvVZ

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Badge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Badge" (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    emoji text NOT NULL,
    description text NOT NULL,
    color text DEFAULT '9B4FD6'::text NOT NULL
);


--
-- Name: CardBattleTeam; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CardBattleTeam" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "guildId" text NOT NULL,
    "cardKeys" text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ChatLock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ChatLock" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    "channelId" text NOT NULL,
    "allowedRoleIds" text DEFAULT ''::text NOT NULL,
    "lockedById" text NOT NULL,
    "lockedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: CopaConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CopaConfig" (
    id integer DEFAULT 1 NOT NULL,
    "guildId" text DEFAULT ''::text NOT NULL,
    "announcementChannelId" text DEFAULT ''::text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    "emojiHomeWin" text DEFAULT '🏠'::text NOT NULL,
    "emojiDraw" text DEFAULT '🤝'::text NOT NULL,
    "emojiAwayWin" text DEFAULT '✈️'::text NOT NULL,
    "pointsWin" integer DEFAULT 3 NOT NULL,
    "pointsDraw" integer DEFAULT 1 NOT NULL,
    "pointsExact" integer DEFAULT 5 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CopaMatch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CopaMatch" (
    id integer NOT NULL,
    "teamA" text NOT NULL,
    "teamB" text NOT NULL,
    "teamAFlag" text DEFAULT ''::text NOT NULL,
    "teamBFlag" text DEFAULT ''::text NOT NULL,
    "matchDate" timestamp(3) without time zone NOT NULL,
    phase text DEFAULT 'Fase de Grupos'::text NOT NULL,
    "group" text DEFAULT ''::text NOT NULL,
    stadium text DEFAULT ''::text NOT NULL,
    "bannerUrl" text DEFAULT ''::text NOT NULL,
    "channelId" text DEFAULT ''::text NOT NULL,
    "messageId" text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "scoreA" integer,
    "scoreB" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CopaMatch_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."CopaMatch_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: CopaMatch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."CopaMatch_id_seq" OWNED BY public."CopaMatch".id;


--
-- Name: CopaPrediction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CopaPrediction" (
    id integer NOT NULL,
    "matchId" integer NOT NULL,
    "discordUserId" text NOT NULL,
    "discordUsername" text DEFAULT ''::text NOT NULL,
    prediction text NOT NULL,
    points integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CopaPrediction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."CopaPrediction_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: CopaPrediction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."CopaPrediction_id_seq" OWNED BY public."CopaPrediction".id;


--
-- Name: CustomBanner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CustomBanner" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    price integer DEFAULT 1000 NOT NULL,
    "imageUrl" text NOT NULL,
    gradient1 text DEFAULT '#1a0533'::text NOT NULL,
    gradient2 text DEFAULT '#4a1a8a'::text NOT NULL,
    emoji text DEFAULT '🖼️'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Economy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Economy" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "guildId" text NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    bank integer DEFAULT 0 NOT NULL,
    "messageCount" integer DEFAULT 0 NOT NULL,
    "callMinutes" integer DEFAULT 0 NOT NULL,
    xp integer DEFAULT 0 NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    "lastDaily" timestamp(3) without time zone,
    "lastWork" timestamp(3) without time zone,
    "dailyStreak" integer DEFAULT 0 NOT NULL,
    "lastPetPlay" timestamp(3) without time zone,
    "lastPetFeed" timestamp(3) without time zone,
    "lastPetPet" timestamp(3) without time zone
);


--
-- Name: Economy_global_backup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Economy_global_backup" (
    id text,
    "userId" text,
    balance integer,
    bank integer,
    "messageCount" integer,
    "callMinutes" integer,
    xp integer,
    level integer,
    "lastDaily" timestamp(3) without time zone,
    "lastWork" timestamp(3) without time zone,
    "dailyStreak" integer,
    "lastPetPlay" timestamp(3) without time zone,
    "lastPetFeed" timestamp(3) without time zone,
    "lastPetPet" timestamp(3) without time zone
);


--
-- Name: FishingCatch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FishingCatch" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "guildId" text NOT NULL,
    "fishKey" text NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    "qualityTotal" integer DEFAULT 0 NOT NULL
);


--
-- Name: FishingProfile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FishingProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "guildId" text NOT NULL,
    "rodKey" text DEFAULT 'bambu'::text NOT NULL,
    "lastFishing" timestamp(3) without time zone,
    "totalCaught" integer DEFAULT 0 NOT NULL,
    "sealBlessing" boolean DEFAULT false NOT NULL,
    "sharkBattleHp" integer DEFAULT 0 NOT NULL,
    "sharkBattleReward" integer DEFAULT 0 NOT NULL,
    "legendaryBattleUserId" text,
    "legendaryBattleRound" integer DEFAULT 0 NOT NULL,
    "legendaryBattleChoice" text,
    "legendaryBattleExpiresAt" timestamp without time zone
);


--
-- Name: GuildBadgeEmoji; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GuildBadgeEmoji" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    "badgeKey" text NOT NULL,
    emoji text NOT NULL
);


--
-- Name: GuildConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GuildConfig" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    "ticketChannel" text,
    "ticketCategory" text,
    "ticketColor" text,
    "ticketBanner" text,
    "ticketThumb" text,
    "ticketFooter" text,
    "ticketTitle" text,
    "ticketText" text,
    "ticketPingRole" text,
    "ticketPingUser" text,
    "ticketBtnLabel" text,
    "ticketBtnEmoji" text,
    "ticketBtnStyle" text,
    "ticketOpenText" text,
    "ticketUseSeparator" boolean DEFAULT false NOT NULL,
    "ticketQuestion1" text,
    "ticketQuestion2" text,
    "ticketQuestion3" text,
    "instaChannel" text,
    "instaColor" text,
    "instaEmoji" text DEFAULT '💜'::text NOT NULL,
    "tellonymChannel" text,
    "tellonymColor" text,
    "tellonymBanner" text,
    "tellonymThumb" text,
    "tellonymFooter" text,
    "tellonymTitle" text,
    "tellonymText" text,
    "lojaTitle" text,
    "lojaText" text,
    "lojaBanner" text,
    "lojaThumb" text,
    "lojaColor" text,
    "lojaConversao" text,
    "lojaUseDivider" boolean DEFAULT false NOT NULL,
    "shopEmojiComprar" text,
    "shopEmojiVitrine" text,
    "shopEmojiConverter" text,
    "shopEmojiSaldo" text,
    "shopEmojiGift" text,
    "welcomeEnabled" boolean DEFAULT true NOT NULL,
    "welcomeChannel" text,
    "welcomeColor" text,
    "welcomeBanner" text,
    "welcomeThumb" text,
    "welcomeFooter" text,
    "welcomeTitle" text,
    "welcomeText" text,
    "welcomeRoles" text,
    "welcomeChannels" text,
    "partnerEnabled" boolean DEFAULT false NOT NULL,
    "partnerChannel" text,
    "partnerResponsibleRole" text,
    "partnerPingRole" text,
    "partnerRole" text,
    "partnerNotifyDm" boolean DEFAULT false NOT NULL,
    "partnerMessage" text,
    "partnerImage" text,
    "partnerThumbnail" text,
    "partnerFooter" text,
    "partnerColor" text,
    "partnerRemoveOnLeave" boolean DEFAULT false NOT NULL,
    "instaHandle" text,
    "tellonymBtnEmoji" text,
    "tellonymBtnLabel" text,
    "welcomeBannerPosition" text DEFAULT 'top'::text NOT NULL,
    "welcomeDeleteAfter" integer,
    "welcomeShowAvatar" boolean DEFAULT true NOT NULL,
    "welcomeShowTitle" boolean DEFAULT true NOT NULL,
    "welcomeUseDivider" boolean DEFAULT false NOT NULL,
    "ticketBannerPosition" text DEFAULT 'top'::text NOT NULL,
    "ticketOnlyBanner" boolean DEFAULT false NOT NULL,
    "ticketUseMenu" boolean DEFAULT false NOT NULL,
    "botBannerUrl" text,
    "botBio" text,
    "botIconUrl" text,
    "aiChannelId" text,
    "vipBanner" text,
    "vipBtnCarrinhoLabel" text,
    "vipBtnEscolherLabel" text,
    "vipColor" text,
    "vipPriceLabel" text,
    "vipText" text,
    "vipThumb" text,
    "vipTitle" text,
    "vipEmojiBtn1" text,
    "vipEmojiBtn2" text,
    "vipEmojiCoin" text,
    "vipEmojiTag" text,
    "vipIntro" text,
    "shopBtnStyles" text,
    "lojaBannerPos" text DEFAULT 'top'::text,
    "ticketAiEnabled" boolean DEFAULT false NOT NULL,
    "antiLinkEnabled" boolean DEFAULT false NOT NULL,
    "antiLinkAction" text DEFAULT 'delete_warn'::text NOT NULL,
    "antiLinkBlockDiscord" boolean DEFAULT true NOT NULL,
    "antiLinkBlockSocial" boolean DEFAULT true NOT NULL,
    "antiLinkBlockShorteners" boolean DEFAULT true NOT NULL,
    "antiLinkAllowedDomains" text,
    "antiLinkAllowedChannels" text,
    "antiLinkAllowedRoles" text,
    "antiLinkLogChannel" text,
    "antiLinkBlockAll" boolean DEFAULT true NOT NULL,
    "ticketPanelMessageId" text,
    "ticketPanelChannelId" text,
    "presencedEnabled" boolean DEFAULT false NOT NULL,
    "presencedConsoles" text DEFAULT 'PS3,WiiU'::text NOT NULL,
    "presencedPollInterval" integer DEFAULT 10 NOT NULL,
    "presencedPs3Address" text,
    "presencedPs3Network" text DEFAULT 'PSN'::text NOT NULL,
    "presencedPs3NetworkFull" text DEFAULT 'PlayStation Network'::text NOT NULL,
    "presencedPs3NetworkId" text DEFAULT '{anon-user}'::text NOT NULL,
    "presencedPs3UseCelsius" boolean DEFAULT true NOT NULL,
    "presencedWiiuPort" integer DEFAULT 5005 NOT NULL,
    "presencedWiiuFirmware" text DEFAULT '{unknown-ver}'::text NOT NULL,
    "presencedWiiuHardware" text DEFAULT 'IBM Espresso | AMD Latte'::text NOT NULL,
    "bumpEnabled" boolean DEFAULT false NOT NULL,
    "bumpChannel" text,
    "bumpNextAt" timestamp(3) without time zone,
    "bumpRole" text,
    "partnerDescription" text,
    "partnerMinMembers" integer
);


--
-- Name: Interaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Interaction" (
    id text NOT NULL,
    type text NOT NULL,
    "fromId" text NOT NULL,
    "toId" text NOT NULL,
    "guildId" text,
    count integer DEFAULT 1 NOT NULL
);


--
-- Name: PanelPreset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PanelPreset" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    type text NOT NULL,
    name text NOT NULL,
    color text,
    banner text,
    thumb text,
    footer text,
    title text,
    text text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Partnership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Partnership" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    "partnerServerId" text NOT NULL,
    "partnerName" text NOT NULL,
    "promoterId" text NOT NULL,
    "representativeId" text,
    "inviteCode" text NOT NULL,
    "messageUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Pet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Pet" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    name text NOT NULL,
    emoji text NOT NULL,
    "imageUrl" text,
    description text,
    price integer NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PublishedMsgData; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PublishedMsgData" (
    "messageId" text NOT NULL,
    "guildId" text NOT NULL,
    data text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ShopRole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ShopRole" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    "roleId" text NOT NULL,
    name text NOT NULL,
    description text,
    price integer NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: TellonymProfile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TellonymProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    link text NOT NULL
);


--
-- Name: Ticket; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Ticket" (
    id text NOT NULL,
    "channelId" text NOT NULL,
    "userId" text NOT NULL,
    "guildId" text NOT NULL,
    reason text,
    answer1 text,
    answer2 text,
    answer3 text,
    "claimedBy" text,
    status text DEFAULT 'open'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: TicketOption; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TicketOption" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    label text NOT NULL,
    emoji text DEFAULT '🎫'::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "pingRole" text DEFAULT ''::text NOT NULL,
    "pingUser" text DEFAULT ''::text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: UserBadge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserBadge" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "badgeKey" text NOT NULL,
    "earnedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: UserProfile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "guildId" text,
    "activeBanner" text,
    "activeRing" text,
    "ringBorderColor" text,
    "activePet" text,
    bio text,
    "marriedTo" text,
    "marriedToName" text,
    "bestFriendId" text,
    "bestFriendName" text,
    reps integer DEFAULT 0 NOT NULL,
    "cardBg1" text,
    "cardBg2" text,
    "cardPanelColor" text,
    "walletBg" text,
    "walletRing" text,
    "walletRingBorder" text,
    "walletFrame" text
);


--
-- Name: UserPurchase; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserPurchase" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "guildId" text,
    "itemType" text NOT NULL,
    "itemRef" text NOT NULL,
    "purchasedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: UserQuestToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserQuestToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: VipGrant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VipGrant" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    "userId" text NOT NULL,
    "roleId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: VipPlan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VipPlan" (
    id text NOT NULL,
    "guildId" text NOT NULL,
    name text NOT NULL,
    price text NOT NULL,
    emoji text,
    "roleId" text,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: CopaMatch id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CopaMatch" ALTER COLUMN id SET DEFAULT nextval('public."CopaMatch_id_seq"'::regclass);


--
-- Name: CopaPrediction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CopaPrediction" ALTER COLUMN id SET DEFAULT nextval('public."CopaPrediction_id_seq"'::regclass);


--
-- Data for Name: Badge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Badge" (id, key, name, emoji, description, color) FROM stdin;
\.


--
-- Data for Name: CardBattleTeam; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CardBattleTeam" (id, "userId", "guildId", "cardKeys", "updatedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: ChatLock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ChatLock" (id, "guildId", "channelId", "allowedRoleIds", "lockedById", "lockedAt") FROM stdin;
\.


--
-- Data for Name: CopaConfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CopaConfig" (id, "guildId", "announcementChannelId", enabled, "emojiHomeWin", "emojiDraw", "emojiAwayWin", "pointsWin", "pointsDraw", "pointsExact", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CopaMatch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CopaMatch" (id, "teamA", "teamB", "teamAFlag", "teamBFlag", "matchDate", phase, "group", stadium, "bannerUrl", "channelId", "messageId", status, "scoreA", "scoreB", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CopaPrediction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CopaPrediction" (id, "matchId", "discordUserId", "discordUsername", prediction, points, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CustomBanner; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CustomBanner" (id, "guildId", key, name, description, price, "imageUrl", gradient1, gradient2, emoji, active, "createdAt") FROM stdin;
\.


--
-- Data for Name: Economy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Economy" (id, "userId", "guildId", balance, bank, "messageCount", "callMinutes", xp, level, "lastDaily", "lastWork", "dailyStreak", "lastPetPlay", "lastPetFeed", "lastPetPet") FROM stdin;
cmrjyla9d0013fjtw9pa2xac5	1304085617080270911	1514018464069582998	0	0	23	0	351	1	\N	\N	0	\N	\N	\N
cms3ggyn60022ohrs7kwphfr0	1522734208962003087	1514018464069582998	0	0	2	0	29	1	\N	\N	0	\N	\N	\N
cmrljmgvj000yur84tzm0mfxh	1494838446416724118	1514018464069582998	0	0	2	0	36	1	\N	\N	0	\N	\N	\N
cmrmfd3ts000218vb7s9on7mq	1494097528524771418	1514018464069582998	0	0	10	0	151	1	\N	\N	0	\N	\N	\N
cmrjxhp3a00015t9lr615ukke	621506570345512970	1514018464069582998	0	0	8	0	131	1	\N	\N	0	\N	\N	\N
cms2ocd480000ifed7a639tyv	1527154150540841000	1514018464069582998	0	0	204	0	3027	1	\N	\N	0	\N	\N	\N
cmrlm6r6c002vs3ojvvcmsnuv	1305702757960777862	1514018464069582998	0	0	2	0	29	1	\N	\N	0	\N	\N	\N
cms25nqy1000k13dhxuvfqz3v	1511503064501321859	1514018464069582998	0	0	29	0	419	1	\N	\N	0	\N	\N	\N
cmrjz68c00063fjtwv3emjkp0	1449146684960538754	1514018464069582998	0	0	139	0	2101	1	\N	\N	0	\N	\N	\N
cmrll9qy70004s3oju2532j4y	1390600596809191424	1514018464069582998	0	0	8	0	133	1	\N	\N	0	\N	\N	\N
cmrjwoq3r000d71g8kfupidlr	766044576770686976	1514018464069582998	0	0	226	0	3408	1	\N	\N	0	\N	\N	\N
cmrjz3mj70057fjtwyw24ibk8	1008894638050000928	1514018464069582998	0	0	3	0	40	1	\N	\N	0	\N	\N	\N
cmrkx2niq0026yz9siolmv9ou	670069747534135312	1514018464069582998	0	0	1	0	19	1	\N	\N	0	\N	\N	\N
cmrljdwwx001lwaqjs00qvpq1	1516222342840324210	1514018464069582998	0	0	3	0	51	1	\N	\N	0	\N	\N	\N
cmrljv38j002aur84sjgmush1	1314074596563091537	1514018464069582998	0	0	3	0	51	1	\N	\N	0	\N	\N	\N
cmrjysjck001nfjtwcrpwg55l	997181212097523764	1514018464069582998	0	0	36	0	535	1	\N	\N	0	\N	\N	\N
cmrjy9lge0000fjtwvf07lek6	1515402905216221245	1514018464069582998	0	0	36	0	541	1	\N	\N	0	\N	\N	\N
cms3z65hv002ei473hr14gpmu	1490431427932590213	1514018464069582998	0	0	13	0	176	1	\N	\N	0	\N	\N	\N
cmrk0ai0j002k1zcwzldd74l3	1332515666149769246	1514018464069582998	0	0	42	0	633	1	\N	\N	0	\N	\N	\N
cmrjx3cch00006ydkt6lgaoiu	904483863110225931	1514018464069582998	0	0	118	0	1792	1	\N	\N	0	\N	\N	\N
cmrkr3y150004klzt2nz9bvkz	1515434655053254709	1514018464069582998	0	0	15	0	219	1	\N	\N	0	\N	\N	\N
cmrkww5b7000cyz9suvolsjqx	1318339262789451790	1514018464069582998	0	0	9	0	125	1	\N	\N	0	\N	\N	\N
cms3zop6y009zi473jp7c0h5d	1526010141156048936	1514018464069582998	0	0	12	0	156	1	\N	\N	0	\N	\N	\N
cms3z0a6b0000i473os5poxxg	1524611313706340402	1514018464069582998	0	0	116	0	1768	1	\N	\N	0	\N	\N	\N
cmrlmp94y003is3oj8kpa6wc1	1390694531871150091	1514018464069582998	0	0	1	0	10	1	\N	\N	0	\N	\N	\N
cms2p8txq007difed89o1acnv	1529614090526265424	1514018464069582998	0	0	3	0	44	1	\N	\N	0	\N	\N	\N
cmrkrdn9b0005ayyaj63zy249	1524156529471651942	1514018464069582998	0	0	2	0	32	1	\N	\N	0	\N	\N	\N
cmrjwmm8f000171g8b311aue6	1513613689322995804	1514018464069582998	0	0	260	0	3497	1	\N	\N	0	\N	\N	\N
cmrjx5ry500086ydkrghwvb28	1524199651354349689	1514018464069582998	0	0	9	0	136	1	\N	\N	0	\N	\N	\N
cmrjx7iit000h6ydktisi22v2	1286426809264509053	1514018464069582998	0	0	40	0	594	1	\N	\N	0	\N	\N	\N
cmrjxmmu800055t9lg24yafln	1436735793891643542	1514018464069582998	0	0	4	0	61	1	\N	\N	0	\N	\N	\N
cms3z0fxy0005i473lr5hkvc3	1318632587220222048	1514018464069582998	0	0	3	0	53	1	\N	\N	0	\N	\N	\N
cmrkwt7xe0009yz9srv3h3b35	1517966583740502219	1514018464069582998	0	0	3	0	42	1	\N	\N	0	\N	\N	\N
cmrjwoywt000i71g8ayqbqpkl	1510918703640875028	1514018464069582998	733	0	92	0	960	1	2026-07-15 03:53:53.221	\N	1	\N	\N	\N
cmrvd5z7u001g1a8gdrmpobyq	799371658082123796	1514018464069582998	0	0	122	0	1814	1	\N	\N	0	\N	\N	\N
cmrmm1ues0007owyjbqfg306b	1246868064268714035	1514018464069582998	0	0	23	0	344	1	\N	\N	0	\N	\N	\N
cmru79yjs0000uj0pz6filaru	1528963691129868319	1514018464069582998	0	0	2	0	30	1	\N	\N	0	\N	\N	\N
cmrksiwbt0003ktqme0lk9x6j	1526397562095927308	1514018464069582998	0	0	1	0	13	1	\N	\N	0	\N	\N	\N
cms3ggek1001uohrsu3dagxia	1473730672534491290	1514018464069582998	0	0	21	0	304	1	\N	\N	0	\N	\N	\N
cmrvei949004vi56tqrifasar	1167346378561826876	1514018464069582998	0	0	21	0	318	1	\N	\N	0	\N	\N	\N
cmrksmldq0005ug1e8wnrw3g1	1505677624775540858	1514018464069582998	0	0	1	0	16	1	\N	\N	0	\N	\N	\N
cms3gownu0051ohrspoah39lp	1412231327184588890	1514018464069582998	0	0	1	0	18	1	\N	\N	0	\N	\N	\N
cms3z1dzz000ki473h7b84274	1500323659649384608	1514018464069582998	0	0	5	0	78	1	\N	\N	0	\N	\N	\N
cmrk06kdw00111zcwlj8ex583	1519763285535101010	1514018464069582998	0	0	224	0	3364	1	\N	\N	0	\N	\N	\N
cmrvcuio800071a8gtlvs6q0u	1525921255587319946	1514018464069582998	0	0	1	0	17	1	\N	\N	0	\N	\N	\N
cmrjwl1gu0000125b0zd7bxgn	1342135704058204263	1514018464069582998	0	0	505	0	7592	1	\N	\N	0	\N	\N	\N
cmrljhbsc0001ur84a979v67j	617115299853893649	1514018464069582998	0	0	1	0	11	1	\N	\N	0	\N	\N	\N
cmrvd062q000m1a8gomkfh3ow	1529262033764356189	1514018464069582998	0	0	0	1	0	1	\N	\N	0	\N	\N	\N
cmrjxa7qv000x6ydkmgccjqs9	1507584426366992485	1514018464069582998	0	0	49	0	756	1	\N	\N	0	\N	\N	\N
cmrjwm878000071g8gvzrgu32	1302455505163390999	1514018464069582998	0	0	1	0	16	1	\N	\N	0	\N	\N	\N
cmrk13dys0036idinquwo34lq	1526008623552266414	1514018464069582998	0	0	1	0	11	1	\N	\N	0	\N	\N	\N
cmrk12vvb002widina8jf72to	1525939095606398996	1514018464069582998	0	0	27	0	411	1	\N	\N	0	\N	\N	\N
cmrk3arqd00iridin8fxqdyjc	1493346171119206412	1514018464069582998	0	0	13	0	190	1	\N	\N	0	\N	\N	\N
cmrjzw2go000aag0kertvor52	950171397353783326	1514018464069582998	0	0	290	0	4359	1	\N	\N	0	\N	\N	\N
cmrm6iipu000e10dnjp74gvsi	1024775581168054374	1514018464069582998	0	0	1	0	10	1	\N	\N	0	\N	\N	\N
cmrjwne9w000371g88dqu87ix	1524207986652876972	1514018464069582998	0	0	14	0	200	1	\N	\N	0	\N	\N	\N
cmrkx5knb002vyz9so1qcpyal	1522984828507787547	1514018464069582998	0	0	2	0	25	1	\N	\N	0	\N	\N	\N
cms1ycupa000425lmtm15j08m	1466873634407583774	1514018464069582998	0	0	3	0	49	1	\N	\N	0	\N	\N	\N
cmrk17wfc005pidinlbqn6o6p	890228161986572340	1514018464069582998	0	0	18	0	265	1	\N	\N	0	\N	\N	\N
cmrk33p7800ieidinm8io1uxu	1492660602504478850	1514018464069582998	0	0	7	0	106	1	\N	\N	0	\N	\N	\N
cmrk2mcrb00gyidinry72bzcw	1038568005501726730	1514018464069582998	0	0	17	0	248	1	\N	\N	0	\N	\N	\N
cmrv1pvof00045h8xm94ayldx	1527348620075077694	1514018464069582998	0	0	1	0	11	1	\N	\N	0	\N	\N	\N
cms2ocgaa0003ifedscw19trj	1498087985357389956	1514018464069582998	0	0	17	0	262	1	\N	\N	0	\N	\N	\N
cmrk2e6qs00gkidinpjdg4lqa	701279322849280040	1514018464069582998	0	0	18	0	255	1	\N	\N	0	\N	\N	\N
cms25wpny003813dhwmw6j78k	1527094211176828951	1514018464069582998	0	0	86	0	1292	1	\N	\N	0	\N	\N	\N
cmrjz5t11005tfjtwc6vmrs51	1320100322881962026	1514018464069582998	0	0	7	0	110	1	\N	\N	0	\N	\N	\N
cmrk2pkzi00h1idin6gvyid1q	739150339357409300	1514018464069582998	0	0	24	0	366	1	\N	\N	0	\N	\N	\N
cmrmfd0p1000118vbzogqxtz8	1517014102915153940	1514018464069582998	0	0	1	0	16	1	\N	\N	0	\N	\N	\N
cmrksp90e000cug1epmie1957	1504162079966498856	1514018464069582998	0	0	1	0	18	1	\N	\N	0	\N	\N	\N
cms3gkp3e003hohrsvupdydhp	1028709819667980403	1514018464069582998	0	0	29	0	434	1	\N	\N	0	\N	\N	\N
cmrjyrqun001hfjtw2vnhjo8f	1513736341425225859	1514018464069582998	0	0	41	0	625	1	\N	\N	0	\N	\N	\N
cms2odas10007ifedgg5jlyci	1511013863364235375	1514018464069582998	0	0	24	0	366	1	\N	\N	0	\N	\N	\N
cmrk1uw1y00g4idinffaksmic	1495521217845919908	1514018464069582998	0	0	1	0	18	1	\N	\N	0	\N	\N	\N
cmrv1sfc700065h8x3qfwilx7	1325138061155373187	1514018464069582998	0	0	2	0	28	1	\N	\N	0	\N	\N	\N
cms408mvi00i4i473d6i100js	1218673213144432690	1514018464069582998	0	0	2	0	27	1	\N	\N	0	\N	\N	\N
cms3z7d4o002yi4730iz14qu6	1531327279341240385	1514018464069582998	0	0	36	0	527	1	\N	\N	0	\N	\N	\N
cmrkwwodq000gyz9slgsl8vli	1522482468219912224	1514018464069582998	0	0	119	0	1724	1	\N	\N	0	\N	\N	\N
cmrk03yv000041zcwr193h4zx	1313174888495714306	1514018464069582998	0	0	2	0	34	1	\N	\N	0	\N	\N	\N
cms25xrmr003e13dhhzt95zyh	1520019414198517841	1514018464069582998	0	0	6	0	88	1	\N	\N	0	\N	\N	\N
cmrv1o74e00015h8xra9baig1	1512605692282798151	1514018464069582998	0	0	4	0	46	1	\N	\N	0	\N	\N	\N
cmrveuac6006ti56toa35k5ag	1430378352300134554	1514018464069582998	0	0	8	0	114	1	\N	\N	0	\N	\N	\N
cmrvd5qep001c1a8g2dneuakt	1521608460540575791	1514018464069582998	0	0	66	0	996	1	\N	\N	0	\N	\N	\N
cmrjwojw6000871g8d4j66myt	1293007181284905062	1514018464069582998	0	0	2	0	36	1	\N	\N	0	\N	\N	\N
cmrk10uf60024idin9qvn6whi	1495640075537485934	1514018464069582998	0	0	142	0	2158	1	\N	\N	0	\N	\N	\N
cmrjyc13v0004fjtwwvqwj3qt	1513602309215486084	1514018464069582998	0	0	3	0	44	1	\N	\N	0	\N	\N	\N
cmrksq7tx000fug1emrq66qty	1526439706580221993	1514018464069582998	0	0	1	0	13	1	\N	\N	0	\N	\N	\N
cms1ycxuf000525lm4r1lk6ub	1527095984776282133	1514018464069582998	0	0	81	0	1227	1	\N	\N	0	\N	\N	\N
cmrjzvrlr0006ag0ki6jumkmn	1526064503173681315	1514018464069582998	0	0	151	0	2243	1	\N	\N	0	\N	\N	\N
cms25ta3k002c13dh2qdalpbk	1522568928487014451	1514018464069582998	0	0	97	0	1479	1	\N	\N	0	\N	\N	\N
cmrvd4i4i00161a8g7cfpzrxr	969268641885474898	1514018464069582998	0	0	31	0	442	1	\N	\N	0	\N	\N	\N
\.


--
-- Data for Name: Economy_global_backup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Economy_global_backup" (id, "userId", balance, bank, "messageCount", "callMinutes", xp, level, "lastDaily", "lastWork", "dailyStreak", "lastPetPlay", "lastPetFeed", "lastPetPet") FROM stdin;
cmrjz3mj70057fjtwyw24ibk8	1008894638050000928	0	0	3	0	40	1	\N	\N	0	\N	\N	\N
cmrm6iipu000e10dnjp74gvsi	1024775581168054374	0	0	1	0	10	1	\N	\N	0	\N	\N	\N
cms3gkp3e003hohrsvupdydhp	1028709819667980403	0	0	29	0	434	1	\N	\N	0	\N	\N	\N
cmrk2mcrb00gyidinry72bzcw	1038568005501726730	0	0	17	0	248	1	\N	\N	0	\N	\N	\N
cmrvei949004vi56tqrifasar	1167346378561826876	0	0	21	0	318	1	\N	\N	0	\N	\N	\N
cms408mvi00i4i473d6i100js	1218673213144432690	0	0	2	0	27	1	\N	\N	0	\N	\N	\N
cmrmm1ues0007owyjbqfg306b	1246868064268714035	0	0	23	0	344	1	\N	\N	0	\N	\N	\N
cmrjx7iit000h6ydktisi22v2	1286426809264509053	0	0	40	0	594	1	\N	\N	0	\N	\N	\N
cmrjwojw6000871g8d4j66myt	1293007181284905062	0	0	2	0	36	1	\N	\N	0	\N	\N	\N
cmrjwm878000071g8gvzrgu32	1302455505163390999	0	0	1	0	16	1	\N	\N	0	\N	\N	\N
cmrjyla9d0013fjtw9pa2xac5	1304085617080270911	0	0	23	0	351	1	\N	\N	0	\N	\N	\N
cmrlm6r6c002vs3ojvvcmsnuv	1305702757960777862	0	0	2	0	29	1	\N	\N	0	\N	\N	\N
cmrk03yv000041zcwr193h4zx	1313174888495714306	0	0	2	0	34	1	\N	\N	0	\N	\N	\N
cmrljv38j002aur84sjgmush1	1314074596563091537	0	0	3	0	51	1	\N	\N	0	\N	\N	\N
cmrkww5b7000cyz9suvolsjqx	1318339262789451790	0	0	9	0	125	1	\N	\N	0	\N	\N	\N
cms3z0fxy0005i473lr5hkvc3	1318632587220222048	0	0	3	0	53	1	\N	\N	0	\N	\N	\N
cmrjz5t11005tfjtwc6vmrs51	1320100322881962026	0	0	7	0	110	1	\N	\N	0	\N	\N	\N
cmrv1sfc700065h8x3qfwilx7	1325138061155373187	0	0	2	0	28	1	\N	\N	0	\N	\N	\N
cmrk0ai0j002k1zcwzldd74l3	1332515666149769246	0	0	42	0	633	1	\N	\N	0	\N	\N	\N
cmrjwl1gu0000125b0zd7bxgn	1342135704058204263	0	0	505	0	7592	1	\N	\N	0	\N	\N	\N
cmrll9qy70004s3oju2532j4y	1390600596809191424	0	0	8	0	133	1	\N	\N	0	\N	\N	\N
cmrlmp94y003is3oj8kpa6wc1	1390694531871150091	0	0	1	0	10	1	\N	\N	0	\N	\N	\N
cms3gownu0051ohrspoah39lp	1412231327184588890	0	0	1	0	18	1	\N	\N	0	\N	\N	\N
cmrveuac6006ti56toa35k5ag	1430378352300134554	0	0	8	0	114	1	\N	\N	0	\N	\N	\N
cmrjxmmu800055t9lg24yafln	1436735793891643542	0	0	4	0	61	1	\N	\N	0	\N	\N	\N
cmrjz68c00063fjtwv3emjkp0	1449146684960538754	0	0	139	0	2101	1	\N	\N	0	\N	\N	\N
cms1ycupa000425lmtm15j08m	1466873634407583774	0	0	3	0	49	1	\N	\N	0	\N	\N	\N
cms3ggek1001uohrsu3dagxia	1473730672534491290	0	0	21	0	304	1	\N	\N	0	\N	\N	\N
cms3z65hv002ei473hr14gpmu	1490431427932590213	0	0	13	0	176	1	\N	\N	0	\N	\N	\N
cmrk33p7800ieidinm8io1uxu	1492660602504478850	0	0	7	0	106	1	\N	\N	0	\N	\N	\N
cmrk3arqd00iridin8fxqdyjc	1493346171119206412	0	0	13	0	190	1	\N	\N	0	\N	\N	\N
cmrmfd3ts000218vb7s9on7mq	1494097528524771418	0	0	10	0	151	1	\N	\N	0	\N	\N	\N
cmrljmgvj000yur84tzm0mfxh	1494838446416724118	0	0	2	0	36	1	\N	\N	0	\N	\N	\N
cmrk1uw1y00g4idinffaksmic	1495521217845919908	0	0	1	0	18	1	\N	\N	0	\N	\N	\N
cmrk10uf60024idin9qvn6whi	1495640075537485934	0	0	142	0	2158	1	\N	\N	0	\N	\N	\N
cms2ocgaa0003ifedscw19trj	1498087985357389956	0	0	17	0	262	1	\N	\N	0	\N	\N	\N
cms3z1dzz000ki473h7b84274	1500323659649384608	0	0	5	0	78	1	\N	\N	0	\N	\N	\N
cmrksp90e000cug1epmie1957	1504162079966498856	0	0	1	0	18	1	\N	\N	0	\N	\N	\N
cmrksmldq0005ug1e8wnrw3g1	1505677624775540858	0	0	1	0	16	1	\N	\N	0	\N	\N	\N
cmrjxa7qv000x6ydkmgccjqs9	1507584426366992485	0	0	49	0	756	1	\N	\N	0	\N	\N	\N
cmrjwoywt000i71g8ayqbqpkl	1510918703640875028	733	0	92	0	960	1	2026-07-15 03:53:53.221	\N	1	\N	\N	\N
cms2odas10007ifedgg5jlyci	1511013863364235375	0	0	24	0	366	1	\N	\N	0	\N	\N	\N
cms25nqy1000k13dhxuvfqz3v	1511503064501321859	0	0	29	0	419	1	\N	\N	0	\N	\N	\N
cmrv1o74e00015h8xra9baig1	1512605692282798151	0	0	4	0	46	1	\N	\N	0	\N	\N	\N
cmrjyc13v0004fjtwwvqwj3qt	1513602309215486084	0	0	3	0	44	1	\N	\N	0	\N	\N	\N
cmrjwmm8f000171g8b311aue6	1513613689322995804	0	0	260	0	3497	1	\N	\N	0	\N	\N	\N
cmrjyrqun001hfjtw2vnhjo8f	1513736341425225859	0	0	41	0	625	1	\N	\N	0	\N	\N	\N
cmrjy9lge0000fjtwvf07lek6	1515402905216221245	0	0	36	0	541	1	\N	\N	0	\N	\N	\N
cmrkr3y150004klzt2nz9bvkz	1515434655053254709	0	0	15	0	219	1	\N	\N	0	\N	\N	\N
cmrljdwwx001lwaqjs00qvpq1	1516222342840324210	0	0	3	0	51	1	\N	\N	0	\N	\N	\N
cmrmfd0p1000118vbzogqxtz8	1517014102915153940	0	0	1	0	16	1	\N	\N	0	\N	\N	\N
cmrkwt7xe0009yz9srv3h3b35	1517966583740502219	0	0	3	0	42	1	\N	\N	0	\N	\N	\N
cmrk06kdw00111zcwlj8ex583	1519763285535101010	0	0	224	0	3364	1	\N	\N	0	\N	\N	\N
cms25xrmr003e13dhhzt95zyh	1520019414198517841	0	0	6	0	88	1	\N	\N	0	\N	\N	\N
cmrvd5qep001c1a8g2dneuakt	1521608460540575791	0	0	66	0	996	1	\N	\N	0	\N	\N	\N
cmrkwwodq000gyz9slgsl8vli	1522482468219912224	0	0	119	0	1724	1	\N	\N	0	\N	\N	\N
cms25ta3k002c13dh2qdalpbk	1522568928487014451	0	0	97	0	1479	1	\N	\N	0	\N	\N	\N
cms3ggyn60022ohrs7kwphfr0	1522734208962003087	0	0	2	0	29	1	\N	\N	0	\N	\N	\N
cmrkx5knb002vyz9so1qcpyal	1522984828507787547	0	0	2	0	25	1	\N	\N	0	\N	\N	\N
cmrkrdn9b0005ayyaj63zy249	1524156529471651942	0	0	2	0	32	1	\N	\N	0	\N	\N	\N
cmrjx5ry500086ydkrghwvb28	1524199651354349689	0	0	9	0	136	1	\N	\N	0	\N	\N	\N
cmrjwne9w000371g88dqu87ix	1524207986652876972	0	0	14	0	200	1	\N	\N	0	\N	\N	\N
cms3z0a6b0000i473os5poxxg	1524611313706340402	0	0	116	0	1768	1	\N	\N	0	\N	\N	\N
cmrvcuio800071a8gtlvs6q0u	1525921255587319946	0	0	1	0	17	1	\N	\N	0	\N	\N	\N
cmrk12vvb002widina8jf72to	1525939095606398996	0	0	27	0	411	1	\N	\N	0	\N	\N	\N
cmrk13dys0036idinquwo34lq	1526008623552266414	0	0	1	0	11	1	\N	\N	0	\N	\N	\N
cms3zop6y009zi473jp7c0h5d	1526010141156048936	0	0	12	0	156	1	\N	\N	0	\N	\N	\N
cmrjzvrlr0006ag0ki6jumkmn	1526064503173681315	0	0	151	0	2243	1	\N	\N	0	\N	\N	\N
cmrksiwbt0003ktqme0lk9x6j	1526397562095927308	0	0	1	0	13	1	\N	\N	0	\N	\N	\N
cmrksq7tx000fug1emrq66qty	1526439706580221993	0	0	1	0	13	1	\N	\N	0	\N	\N	\N
cms25wpny003813dhwmw6j78k	1527094211176828951	0	0	86	0	1292	1	\N	\N	0	\N	\N	\N
cms1ycxuf000525lm4r1lk6ub	1527095984776282133	0	0	81	0	1227	1	\N	\N	0	\N	\N	\N
cms2ocd480000ifed7a639tyv	1527154150540841000	0	0	204	0	3027	1	\N	\N	0	\N	\N	\N
cmrv1pvof00045h8xm94ayldx	1527348620075077694	0	0	1	0	11	1	\N	\N	0	\N	\N	\N
cmru79yjs0000uj0pz6filaru	1528963691129868319	0	0	2	0	30	1	\N	\N	0	\N	\N	\N
cmrvd062q000m1a8gomkfh3ow	1529262033764356189	0	0	0	1	0	1	\N	\N	0	\N	\N	\N
cms2p8txq007difed89o1acnv	1529614090526265424	0	0	3	0	44	1	\N	\N	0	\N	\N	\N
cms3z7d4o002yi4730iz14qu6	1531327279341240385	0	0	36	0	527	1	\N	\N	0	\N	\N	\N
cmrljhbsc0001ur84a979v67j	617115299853893649	0	0	1	0	11	1	\N	\N	0	\N	\N	\N
cmrjxhp3a00015t9lr615ukke	621506570345512970	0	0	8	0	131	1	\N	\N	0	\N	\N	\N
cmrkx2niq0026yz9siolmv9ou	670069747534135312	0	0	1	0	19	1	\N	\N	0	\N	\N	\N
cmrk2e6qs00gkidinpjdg4lqa	701279322849280040	0	0	18	0	255	1	\N	\N	0	\N	\N	\N
cmrk2pkzi00h1idin6gvyid1q	739150339357409300	0	0	24	0	366	1	\N	\N	0	\N	\N	\N
cmrjwoq3r000d71g8kfupidlr	766044576770686976	0	0	226	0	3408	1	\N	\N	0	\N	\N	\N
cmrvd5z7u001g1a8gdrmpobyq	799371658082123796	0	0	122	0	1814	1	\N	\N	0	\N	\N	\N
cmrk17wfc005pidinlbqn6o6p	890228161986572340	0	0	18	0	265	1	\N	\N	0	\N	\N	\N
cmrjx3cch00006ydkt6lgaoiu	904483863110225931	0	0	118	0	1792	1	\N	\N	0	\N	\N	\N
cmrjzw2go000aag0kertvor52	950171397353783326	0	0	290	0	4359	1	\N	\N	0	\N	\N	\N
cmrvd4i4i00161a8g7cfpzrxr	969268641885474898	0	0	31	0	442	1	\N	\N	0	\N	\N	\N
cmrjysjck001nfjtwcrpwg55l	997181212097523764	0	0	36	0	535	1	\N	\N	0	\N	\N	\N
\.


--
-- Data for Name: FishingCatch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FishingCatch" (id, "userId", "guildId", "fishKey", quantity, "qualityTotal") FROM stdin;
\.


--
-- Data for Name: FishingProfile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FishingProfile" (id, "userId", "guildId", "rodKey", "lastFishing", "totalCaught", "sealBlessing", "sharkBattleHp", "sharkBattleReward", "legendaryBattleUserId", "legendaryBattleRound", "legendaryBattleChoice", "legendaryBattleExpiresAt") FROM stdin;
\.


--
-- Data for Name: GuildBadgeEmoji; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GuildBadgeEmoji" (id, "guildId", "badgeKey", emoji) FROM stdin;
\.


--
-- Data for Name: GuildConfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GuildConfig" (id, "guildId", "ticketChannel", "ticketCategory", "ticketColor", "ticketBanner", "ticketThumb", "ticketFooter", "ticketTitle", "ticketText", "ticketPingRole", "ticketPingUser", "ticketBtnLabel", "ticketBtnEmoji", "ticketBtnStyle", "ticketOpenText", "ticketUseSeparator", "ticketQuestion1", "ticketQuestion2", "ticketQuestion3", "instaChannel", "instaColor", "instaEmoji", "tellonymChannel", "tellonymColor", "tellonymBanner", "tellonymThumb", "tellonymFooter", "tellonymTitle", "tellonymText", "lojaTitle", "lojaText", "lojaBanner", "lojaThumb", "lojaColor", "lojaConversao", "lojaUseDivider", "shopEmojiComprar", "shopEmojiVitrine", "shopEmojiConverter", "shopEmojiSaldo", "shopEmojiGift", "welcomeEnabled", "welcomeChannel", "welcomeColor", "welcomeBanner", "welcomeThumb", "welcomeFooter", "welcomeTitle", "welcomeText", "welcomeRoles", "welcomeChannels", "partnerEnabled", "partnerChannel", "partnerResponsibleRole", "partnerPingRole", "partnerRole", "partnerNotifyDm", "partnerMessage", "partnerImage", "partnerThumbnail", "partnerFooter", "partnerColor", "partnerRemoveOnLeave", "instaHandle", "tellonymBtnEmoji", "tellonymBtnLabel", "welcomeBannerPosition", "welcomeDeleteAfter", "welcomeShowAvatar", "welcomeShowTitle", "welcomeUseDivider", "ticketBannerPosition", "ticketOnlyBanner", "ticketUseMenu", "botBannerUrl", "botBio", "botIconUrl", "aiChannelId", "vipBanner", "vipBtnCarrinhoLabel", "vipBtnEscolherLabel", "vipColor", "vipPriceLabel", "vipText", "vipThumb", "vipTitle", "vipEmojiBtn1", "vipEmojiBtn2", "vipEmojiCoin", "vipEmojiTag", "vipIntro", "shopBtnStyles", "lojaBannerPos", "ticketAiEnabled", "antiLinkEnabled", "antiLinkAction", "antiLinkBlockDiscord", "antiLinkBlockSocial", "antiLinkBlockShorteners", "antiLinkAllowedDomains", "antiLinkAllowedChannels", "antiLinkAllowedRoles", "antiLinkLogChannel", "antiLinkBlockAll", "ticketPanelMessageId", "ticketPanelChannelId", "presencedEnabled", "presencedConsoles", "presencedPollInterval", "presencedPs3Address", "presencedPs3Network", "presencedPs3NetworkFull", "presencedPs3NetworkId", "presencedPs3UseCelsius", "presencedWiiuPort", "presencedWiiuFirmware", "presencedWiiuHardware", "bumpEnabled", "bumpChannel", "bumpNextAt", "bumpRole", "partnerDescription", "partnerMinMembers") FROM stdin;
test-guild-001	1502898258610225304	234567890123456789	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	💜	\N	\N	\N	\N	\N	\N	\N	Loja Principal	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	t	1502898258610225307	#7c3aed	\N	\N	\N	Bem-vindo ao servidor!	Que bom ter você aqui!	\N	\N	t	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	f	\N	\N	\N	top	\N	t	t	f	top	f	f	\N	\N	\N	1502898258610225310	\N	\N	\N	\N	50000	\N	\N	\N	\N	\N	\N	\N	\N	\N	top	f	f	delete_warn	t	t	t	\N	\N	\N	\N	t	\N	\N	f	PS3,WiiU	10	\N	PSN	PlayStation Network	{anon-user}	t	5005	{unknown-ver}	IBM Espresso | AMD Latte	f	\N	\N	\N	\N	\N
\.


--
-- Data for Name: Interaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Interaction" (id, type, "fromId", "toId", "guildId", count) FROM stdin;
\.


--
-- Data for Name: PanelPreset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PanelPreset" (id, "guildId", type, name, color, banner, thumb, footer, title, text, "createdAt") FROM stdin;
\.


--
-- Data for Name: Partnership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Partnership" (id, "guildId", "partnerServerId", "partnerName", "promoterId", "representativeId", "inviteCode", "messageUrl", "createdAt") FROM stdin;
\.


--
-- Data for Name: Pet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Pet" (id, "guildId", name, emoji, "imageUrl", description, price, active, "createdAt") FROM stdin;
\.


--
-- Data for Name: PublishedMsgData; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PublishedMsgData" ("messageId", "guildId", data, "createdAt") FROM stdin;
\.


--
-- Data for Name: ShopRole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ShopRole" (id, "guildId", "roleId", name, description, price, active, "createdAt") FROM stdin;
\.


--
-- Data for Name: TellonymProfile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TellonymProfile" (id, "userId", link) FROM stdin;
\.


--
-- Data for Name: Ticket; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Ticket" (id, "channelId", "userId", "guildId", reason, answer1, answer2, answer3, "claimedBy", status, "createdAt") FROM stdin;
\.


--
-- Data for Name: TicketOption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TicketOption" (id, "guildId", label, emoji, description, "pingRole", "pingUser", "order", "createdAt") FROM stdin;
\.


--
-- Data for Name: UserBadge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UserBadge" (id, "userId", "badgeKey", "earnedAt") FROM stdin;
\.


--
-- Data for Name: UserProfile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UserProfile" (id, "userId", "guildId", "activeBanner", "activeRing", "ringBorderColor", "activePet", bio, "marriedTo", "marriedToName", "bestFriendId", "bestFriendName", reps, "cardBg1", "cardBg2", "cardPanelColor", "walletBg", "walletRing", "walletRingBorder", "walletFrame") FROM stdin;
\.


--
-- Data for Name: UserPurchase; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UserPurchase" (id, "userId", "guildId", "itemType", "itemRef", "purchasedAt") FROM stdin;
\.


--
-- Data for Name: UserQuestToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UserQuestToken" (id, "userId", token, "updatedAt") FROM stdin;
\.


--
-- Data for Name: VipGrant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VipGrant" (id, "guildId", "userId", "roleId", "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: VipPlan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VipPlan" (id, "guildId", name, price, emoji, "roleId", "position") FROM stdin;
cmrver2uy006di56tcthr72rh	1502898258610225304	Vip basic	R$ 0,50 mês	🍨	\N	0
\.


--
-- Name: CopaMatch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."CopaMatch_id_seq"', 1, false);


--
-- Name: CopaPrediction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."CopaPrediction_id_seq"', 1, false);


--
-- Name: Badge Badge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Badge"
    ADD CONSTRAINT "Badge_pkey" PRIMARY KEY (id);


--
-- Name: CardBattleTeam CardBattleTeam_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CardBattleTeam"
    ADD CONSTRAINT "CardBattleTeam_pkey" PRIMARY KEY (id);


--
-- Name: CardBattleTeam CardBattleTeam_userId_guildId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CardBattleTeam"
    ADD CONSTRAINT "CardBattleTeam_userId_guildId_key" UNIQUE ("userId", "guildId");


--
-- Name: ChatLock ChatLock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatLock"
    ADD CONSTRAINT "ChatLock_pkey" PRIMARY KEY (id);


--
-- Name: CopaConfig CopaConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CopaConfig"
    ADD CONSTRAINT "CopaConfig_pkey" PRIMARY KEY (id);


--
-- Name: CopaMatch CopaMatch_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CopaMatch"
    ADD CONSTRAINT "CopaMatch_pkey" PRIMARY KEY (id);


--
-- Name: CopaPrediction CopaPrediction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CopaPrediction"
    ADD CONSTRAINT "CopaPrediction_pkey" PRIMARY KEY (id);


--
-- Name: CustomBanner CustomBanner_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CustomBanner"
    ADD CONSTRAINT "CustomBanner_pkey" PRIMARY KEY (id);


--
-- Name: Economy Economy_guild_restore_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Economy"
    ADD CONSTRAINT "Economy_guild_restore_pkey" PRIMARY KEY (id);


--
-- Name: Economy Economy_guild_restore_userId_guildId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Economy"
    ADD CONSTRAINT "Economy_guild_restore_userId_guildId_key" UNIQUE ("userId", "guildId");


--
-- Name: FishingCatch FishingCatch_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FishingCatch"
    ADD CONSTRAINT "FishingCatch_pkey" PRIMARY KEY (id);


--
-- Name: FishingCatch FishingCatch_userId_guildId_fishKey_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FishingCatch"
    ADD CONSTRAINT "FishingCatch_userId_guildId_fishKey_key" UNIQUE ("userId", "guildId", "fishKey");


--
-- Name: FishingProfile FishingProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FishingProfile"
    ADD CONSTRAINT "FishingProfile_pkey" PRIMARY KEY (id);


--
-- Name: FishingProfile FishingProfile_userId_guildId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FishingProfile"
    ADD CONSTRAINT "FishingProfile_userId_guildId_key" UNIQUE ("userId", "guildId");


--
-- Name: GuildBadgeEmoji GuildBadgeEmoji_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GuildBadgeEmoji"
    ADD CONSTRAINT "GuildBadgeEmoji_pkey" PRIMARY KEY (id);


--
-- Name: GuildConfig GuildConfig_guildId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GuildConfig"
    ADD CONSTRAINT "GuildConfig_guildId_key" UNIQUE ("guildId");


--
-- Name: GuildConfig GuildConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GuildConfig"
    ADD CONSTRAINT "GuildConfig_pkey" PRIMARY KEY (id);


--
-- Name: Interaction Interaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Interaction"
    ADD CONSTRAINT "Interaction_pkey" PRIMARY KEY (id);


--
-- Name: PanelPreset PanelPreset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PanelPreset"
    ADD CONSTRAINT "PanelPreset_pkey" PRIMARY KEY (id);


--
-- Name: Partnership Partnership_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Partnership"
    ADD CONSTRAINT "Partnership_pkey" PRIMARY KEY (id);


--
-- Name: Pet Pet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Pet"
    ADD CONSTRAINT "Pet_pkey" PRIMARY KEY (id);


--
-- Name: PublishedMsgData PublishedMsgData_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PublishedMsgData"
    ADD CONSTRAINT "PublishedMsgData_pkey" PRIMARY KEY ("messageId");


--
-- Name: ShopRole ShopRole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ShopRole"
    ADD CONSTRAINT "ShopRole_pkey" PRIMARY KEY (id);


--
-- Name: TellonymProfile TellonymProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TellonymProfile"
    ADD CONSTRAINT "TellonymProfile_pkey" PRIMARY KEY (id);


--
-- Name: TicketOption TicketOption_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TicketOption"
    ADD CONSTRAINT "TicketOption_pkey" PRIMARY KEY (id);


--
-- Name: Ticket Ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_pkey" PRIMARY KEY (id);


--
-- Name: UserBadge UserBadge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserBadge"
    ADD CONSTRAINT "UserBadge_pkey" PRIMARY KEY (id);


--
-- Name: UserProfile UserProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserProfile"
    ADD CONSTRAINT "UserProfile_pkey" PRIMARY KEY (id);


--
-- Name: UserPurchase UserPurchase_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserPurchase"
    ADD CONSTRAINT "UserPurchase_pkey" PRIMARY KEY (id);


--
-- Name: UserQuestToken UserQuestToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserQuestToken"
    ADD CONSTRAINT "UserQuestToken_pkey" PRIMARY KEY (id);


--
-- Name: VipGrant VipGrant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VipGrant"
    ADD CONSTRAINT "VipGrant_pkey" PRIMARY KEY (id);


--
-- Name: VipPlan VipPlan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VipPlan"
    ADD CONSTRAINT "VipPlan_pkey" PRIMARY KEY (id);


--
-- Name: Badge_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Badge_key_key" ON public."Badge" USING btree (key);


--
-- Name: CardBattleTeam_guildId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CardBattleTeam_guildId_idx" ON public."CardBattleTeam" USING btree ("guildId");


--
-- Name: ChatLock_guildId_channelId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ChatLock_guildId_channelId_key" ON public."ChatLock" USING btree ("guildId", "channelId");


--
-- Name: ChatLock_guildId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ChatLock_guildId_idx" ON public."ChatLock" USING btree ("guildId");


--
-- Name: CopaPrediction_matchId_discordUserId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "CopaPrediction_matchId_discordUserId_key" ON public."CopaPrediction" USING btree ("matchId", "discordUserId");


--
-- Name: CustomBanner_guildId_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "CustomBanner_guildId_key_key" ON public."CustomBanner" USING btree ("guildId", key);


--
-- Name: FishingCatch_userId_guildId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "FishingCatch_userId_guildId_idx" ON public."FishingCatch" USING btree ("userId", "guildId");


--
-- Name: GuildBadgeEmoji_guildId_badgeKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "GuildBadgeEmoji_guildId_badgeKey_key" ON public."GuildBadgeEmoji" USING btree ("guildId", "badgeKey");


--
-- Name: Interaction_type_fromId_toId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Interaction_type_fromId_toId_key" ON public."Interaction" USING btree (type, "fromId", "toId");


--
-- Name: PanelPreset_guildId_type_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PanelPreset_guildId_type_name_key" ON public."PanelPreset" USING btree ("guildId", type, name);


--
-- Name: Pet_guildId_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Pet_guildId_name_key" ON public."Pet" USING btree ("guildId", name);


--
-- Name: ShopRole_guildId_roleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ShopRole_guildId_roleId_key" ON public."ShopRole" USING btree ("guildId", "roleId");


--
-- Name: TellonymProfile_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "TellonymProfile_userId_key" ON public."TellonymProfile" USING btree ("userId");


--
-- Name: TicketOption_guildId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "TicketOption_guildId_idx" ON public."TicketOption" USING btree ("guildId");


--
-- Name: Ticket_channelId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Ticket_channelId_key" ON public."Ticket" USING btree ("channelId");


--
-- Name: UserBadge_userId_badgeKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "UserBadge_userId_badgeKey_key" ON public."UserBadge" USING btree ("userId", "badgeKey");


--
-- Name: UserProfile_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "UserProfile_userId_key" ON public."UserProfile" USING btree ("userId");


--
-- Name: UserPurchase_userId_itemType_itemRef_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "UserPurchase_userId_itemType_itemRef_key" ON public."UserPurchase" USING btree ("userId", "itemType", "itemRef");


--
-- Name: UserQuestToken_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "UserQuestToken_userId_key" ON public."UserQuestToken" USING btree ("userId");


--
-- Name: VipGrant_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "VipGrant_expiresAt_idx" ON public."VipGrant" USING btree ("expiresAt");


--
-- Name: VipGrant_guildId_userId_roleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "VipGrant_guildId_userId_roleId_key" ON public."VipGrant" USING btree ("guildId", "userId", "roleId");


--
-- Name: CopaPrediction CopaPrediction_matchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CopaPrediction"
    ADD CONSTRAINT "CopaPrediction_matchId_fkey" FOREIGN KEY ("matchId") REFERENCES public."CopaMatch"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: VipPlan VipPlan_guildId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VipPlan"
    ADD CONSTRAINT "VipPlan_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES public."GuildConfig"("guildId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict YUxpLEnX1zdOLj2bPFn3ooDAnJlFio1pAtowvtDgFpyHR5hOmN7IduDAAMqyvVZ

